<?php if (is_active_sidebar('envo-online-store-right-sidebar')) { ?>
    <aside id="sidebar" class="col-md-3">
        <?php dynamic_sidebar('envo-online-store-right-sidebar'); ?>
    </aside>
<?php } ?>
