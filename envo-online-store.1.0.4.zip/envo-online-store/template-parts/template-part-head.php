<?php envo_online_store_generate_header_image(); ?>

<div id="site-content" class="container main-container" role="main">
    <div class="page-area">      
